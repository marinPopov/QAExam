﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;

namespace MusicStore
{
    [TestFixture]
    public class LogIn
    {
        IWebDriver driver;

        [SetUp]
        public void OpernBrowser()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://qaf2017demo1-001-site1.dtempurl.com/");

        }
        [Test]
        public void logIn()
        {
            var logInbutton = driver.FindElement(By.Id("loginLink"));
            logInbutton.Click();


            var emailTextBox = driver.FindElement(By.Id("Email"));
            emailTextBox.SendKeys("marinpopov78@gmail.com");

            var passwordTextBox = driver.FindElement(By.Id("Password"));
            passwordTextBox.SendKeys("Exam!44");

            var logIn = driver.FindElement(By.CssSelector("#loginForm > form > div:nth-child(7) > div > input"));
            logIn.Click();


        }
        [Test]
        public void LogOut()
        {
            logIn();

            Thread.Sleep(3000);

            var logOutButton = driver.FindElements(By.CssSelector("#logoutForm > ul > li:nth-child(2) > a"));
            var buttonsCount = logOutButton.Count;
            NUnit.Framework.Assert.IsTrue(buttonsCount > 0);

            logOutButton[0].Click();
            Thread.Sleep(6000);

            logOutButton = driver.FindElements(By.CssSelector("#logoutForm > ul > li:nth-child(2) > a"));
            buttonsCount = logOutButton.Count;
            NUnit.Framework.Assert.IsTrue(buttonsCount == 0);
        }
        [Test]
        public void purchase()
        {
            logIn();

            Thread.Sleep(4000);
             
            var chooseOutButton = driver.FindElements(By.CssSelector("#album-list a"));
            string link = chooseOutButton[0].GetAttribute("href");
            driver.Navigate().GoToUrl(link);

            var buttonsCount = chooseOutButton.Count;
           

            Thread.Sleep(4000);

        }

        //[TearDown]
        //public void CloseBrowser()
        //{
        //    driver.Quit();
        //}
    }
}
